create
    definer = root@localhost procedure ProcessPowerball(IN pb_round int(1), IN day_round int, IN nb1 varchar(2),
                                                        IN nb2 varchar(2), IN nb3 varchar(2), IN nb4 varchar(2),
                                                        IN nb5 varchar(2), IN pb varchar(1), IN pb_terms varchar(1),
                                                        IN pb_oe varchar(1), IN pb_uo varchar(1),
                                                        IN nb_terms varchar(1), IN nb_size varchar(1),
                                                        IN nb_oe varchar(1), IN nb_uo varchar(1), IN nb varchar(3))
BEGIN
  DECLARE _continue INT DEFAULT 0;
  DECLARE iswin INT (1);
  DECLARE bDone INT (1);
  DECLARE codes VARCHAR (10); 
  DECLARE picks VARCHAR (1); /* 픽정보 1또는 0,대 중 소 일때 3 2 1이 될수 있음 */
  DECLARE identify INT (11); /* pb_result_powerball의 아이디 */
  DECLARE userIds INT (11) DEFAULT 0; /* 유저 아이디가 보관되는 변수 */
  DECLARE result TEXT;   /* 한 사용자가 한 회차에 여러 파워볼 게임을 놀았을때 그것을 json구조로 담아서 자료기지에 다시 보관시켜 주게 하는 변수 */
  DECLARE game_types VARCHAR (1); /* 1이면 파워볼 2이면 스피드키노 이 변수 사용하지 않음 현재는 스피드와 파오볼 SP로 갈라져 사용함 */
  DECLARE typess VARCHAR (1); /* 1 일반 픽 2이면 방장픽 */
  DECLARE rounds INT (11); /*파워볼 회차정보 담는 변수*/
  DECLARE not_found_creadit INT DEFAULT 0;
  DECLARE count_win INT DEFAULT 0;/* 연승 개수 담는 변수 */
  DECLARE count_win1 INT DEFAULT 0;/* 연승 개수 담는 변수 */
  DECLARE pick_date DATETIME;
  DECLARE market_id VARCHAR(50); 
  DECLARE levels INT DEFAULT 1; 
  DECLARE upl INT;  
  DECLARE exps INT(11);
  DECLARE user_level VARCHAR(2);
  DECLARE code_name VARCHAR(2);
  DECLARE roomIdx VARCHAR(50);
  DECLARE cur CURSOR FOR
  
  SELECT game_code,pick,userId,id,TYPE FROM pb_betting WHERE pb_betting.`round` = day_round AND pb_betting.`changed` = 0 AND pb_betting.`is_win` = - 1 AND pb_betting.game_type = 1;
 /* 연승 조건 얻는 큐어리 */  
  
  DECLARE cur_betting CURSOR FOR
  SELECT CONCAT('{',GROUP_CONCAT(CONCAT('"',game_code,'"',':','{','"pick":',pick,',','"is_win":',is_win,'}') SEPARATOR ','),'}') AS result,
    pb_betting.`userId`,
    pb_betting.`round`,
    pb_betting.`game_type`,
    pb_betting.`type`,
    pb_betting.`created_date`,
    pb_betting.`roomIdx`
  FROM
    pb_betting
  WHERE pb_betting.`round` = day_round
    AND pb_betting.`changed` = 0 AND pb_betting.`game_type`=1 AND pb_betting.`is_win` > -1
  GROUP BY pb_betting.`userId`,pb_betting.`type`,pb_betting.`game_type` ORDER BY created_date ASC;
  /* 사용자 한 회차당 여러 진행한 게임들을 묶어서 다시 다른 테블에 보관시켜 주는 큐어리 */  
  
  DECLARE userList CURSOR FOR
  SELECT pb_users.`exp`,pb_users.level FROM  pb_users WHERE pb_users.`userId`=userIds;
  
  DECLARE expList CURSOR FOR
  SELECT pb_codedetail.code FROM  pb_codedetail WHERE pb_codedetail.`value1` < exps AND pb_codedetail.`value2`=0 AND pb_codedetail.`class`='0020' ORDER BY pb_codedetail.code DESC LIMIT 1;
  
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET _continue = 1;
  INSERT INTO pb_result_powerball (
    ROUND,
    day_round,
    nb1,
    nb2,
    nb3,
    nb4,
    nb5,
    pb,
    pb_terms,
    pb_oe,
    pb_uo,
    nb_terms,
    nb_size,
    nb_oe,
    nb_uo,
    nb
  )
  VALUES
    (
      pb_round,
      day_round,
      nb1,
      nb2,
      nb3,
      nb4,
      nb5,
      pb,
      pb_terms,
      pb_oe,
      pb_uo,
      nb_terms,
      nb_size,
      nb_oe,
      nb_uo,
      nb
    );
  /* 결과 넣어주기 */    
    
    
  /*  베팅 승부처리 부분  */
  OPEN cur;
  credit_loop :
  LOOP
    FETCH cur INTO codes,picks,userIds,identify,typess;
    IF _continue = 1
    THEN LEAVE credit_loop;
    END IF;
    SET iswin = 2;
    IF codes = "pb_oe"
    AND picks = pb_oe
    THEN SET iswin = 1;
    END IF;
    IF codes = "pb_uo"
    AND picks = pb_uo
    THEN SET iswin = 1;
    END IF;
    IF codes = "nb_oe"
    AND picks = nb_oe
    THEN SET iswin = 1;
    END IF;
    IF codes = "nb_uo"
    AND picks = nb_uo
    THEN SET iswin = 1;
    END IF;
    IF codes = "nb_size"
    AND picks = nb_size
    THEN SET iswin = 1;
    END IF;
    
    IF iswin = 1 THEN
     SELECT SQL_CALC_FOUND_ROWS * FROM pb_betting_ctl WHERE created_date > (SELECT  created_date FROM pb_betting_ctl WHERE userId=userIds AND content LIKE '%"is_win":2%' AND pb_betting_ctl.`userId`=userIds AND pb_betting_ctl.game_type=1 AND pb_betting_ctl.`type`=typess   ORDER BY created_date DESC LIMIT 1) AND pb_betting_ctl.`userId`=userIds AND pb_betting_ctl.game_type=1 AND pb_betting_ctl.`type`=typess;
     SET count_win = FOUND_ROWS();
     IF count_win = 0 THEN SET count_win1 = 1; ELSE SET count_win1 = count_win; END IF;
     
     SET levels = 1;
     
     SELECT SQL_CALC_FOUND_ROWS * FROM pb_item_use  WHERE pb_item_use.`market_id`="SUPER_HIGH_LEVEL_UP" AND pb_item_use.`terms1` <= NOW() AND pb_item_use.`terms2` >=NOW() AND  userId=userIds;	
     SET count_win = FOUND_ROWS();
     IF count_win > 0 THEN SET levels = 4;  END IF;
     
     SELECT SQL_CALC_FOUND_ROWS * FROM pb_item_use  WHERE pb_item_use.`market_id`="HIGH_LEVEL_UP" AND pb_item_use.`terms1` <= NOW() AND pb_item_use.`terms2` >=NOW() AND  userId=userIds;	
     SET count_win = FOUND_ROWS();
     IF count_win > 0 THEN SET levels = 2;END IF;   
     SET upl = levels*1;
     UPDATE
       pb_users
     SET
       pb_users.`exp` = pb_users.`exp` + upl
     WHERE pb_users.`userId` = userIds;
    END IF;
    /* 4번 연승하거나 두번 연승하면 연승한 회수만큼 보너스 경험치를 더 지불해준다. */
    
    UPDATE
      pb_betting
    SET
      pb_betting.`is_win` = iswin
    WHERE pb_betting.id = identify;
  END LOOP;
  CLOSE cur;
  /* pb_betting_ctl에 옮기기 */
  OPEN cur_betting;
  SET _continue = 0;
  credit_loops :
  LOOP
    FETCH cur_betting INTO result,userIds,rounds,game_types,typess,pick_date,roomIdx;
    IF _continue = 1
    THEN LEAVE credit_loops;
    END IF;
    INSERT pb_betting_ctl (
      content,
      userId,
      ROUND,
      game_type,
      TYPE,
      pick_date,
      roomIdx
    )
    VALUES
      (result, userIds, rounds, 1, typess,pick_date,roomIdx);
      OPEN userList;
      SET _continue = 0;
      alohaoe_loop:
      LOOP
		FETCH userList INTO exps,user_level;
		IF _continue = 1 
		THEN SET _continue =0;LEAVE alohaoe_loop;
		END IF;
		
		OPEN expList;
		SET _continue=0;
		exp_loop:
		LOOP 
		FETCH expList INTO code_name;
		IF _continue  = 1 THEN
		SET _continue = 0;LEAVE exp_loop;
		END IF;
		UPDATE pb_users SET pb_users.`level`=code_name WHERE pb_users.`userId`=userIds;
		END LOOP;
		CLOSE expList;
       END LOOP;
       CLOSE userList;
  END LOOP;
  CLOSE cur_betting;
  UPDATE pb_betting SET pb_betting.`changed`=1 WHERE pb_betting.`round`=day_round AND pb_betting.`game_type`=1;
END;

