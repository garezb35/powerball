create
    definer = root@localhost procedure ProcessSpeedKeno(IN speed_round int(1), IN day_round int,
                                                        IN sum_list varchar(100), IN speed_sum varchar(4),
                                                        IN speed_oe varchar(1), IN speed_uo varchar(1))
BEGIN
  DECLARE _continue INT DEFAULT 0;
  DECLARE iswin INT (1);
  DECLARE bDone INT (1);
  DECLARE codes VARCHAR (10);
  DECLARE picks VARCHAR (1);
  DECLARE identify INT (11);
  DECLARE userIds INT (11);
  DECLARE result TEXT;
  DECLARE rounds INT (11);
  DECLARE count_win INT DEFAULT 0;
  DECLARE game_types VARCHAR (1);
  /* 1이면 파워볼 2이면 스피드키노 이 변수 사용하지 않음 현재는 스피드와 파오볼 SP로 갈라져 사용함 */
  DECLARE typess VARCHAR (1);
  declare pick_date datetime;
  /* 1 일반 픽 2이면 방장픽 */
  DECLARE cur CURSOR FOR
  SELECT
    game_code,
    pick,
    userId,
    id
  FROM
    pb_betting
  WHERE pb_betting.`round` = day_round
    AND pb_betting.`changed` = 0
    AND pb_betting.is_win = - 1
    AND pb_betting.`game_type` = 2;
  DECLARE cur_betting CURSOR FOR
  SELECT CONCAT('{',GROUP_CONCAT(CONCAT('"',game_code,'"',':','{','"pick":',pick,',','"is_win":',is_win,'}') SEPARATOR ','),'}') AS result,
    pb_betting.`userId`,
    pb_betting.`round`,
    pb_betting.`game_type`,
    pb_betting.`type`,
    pb_betting.`created_date`
  FROM
    pb_betting
  WHERE pb_betting.`round` = day_round
    AND pb_betting.`changed` = 0
    AND pb_betting.game_type = 2 
    AND pb_betting.`is_win` > -1 
  GROUP BY pb_betting.`userId`,
    pb_betting.`type`,
    pb_betting.game_type
  ORDER BY created_date ASC;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET _continue = 1;
  INSERT INTO pb_result_speedkeno (
    ROUND,
    day_round,
    sum_list,
    speed_sum,
    speed_oe,
    speed_uo
  )
  VALUES
    (
      speed_round,
      day_round,
      sum_list,
      speed_sum,
      speed_oe,
      speed_uo
    );
  OPEN cur;
  credit_loop :
  LOOP
    FETCH cur INTO codes,picks,userIds,identify;
    IF _continue = 1
    THEN LEAVE credit_loop;
    END IF;
    SET iswin = 2;
    IF codes = "speed_oe" AND picks = speed_oe THEN SET iswin = 1;END IF;
    IF codes = "speed_uo" AND picks = speed_uo THEN SET iswin = 1;END IF;
   IF iswin = 1 THEN
     SELECT SQL_CALC_FOUND_ROWS * FROM pb_betting_ctl WHERE created_date > (SELECT  created_date FROM pb_betting_ctl WHERE userId=userIds AND content LIKE '%"is_win":2%' AND pb_betting_ctl.`userId`=userIds AND pb_betting_ctl.game_type=2 AND pb_betting_ctl.`type`=typess   ORDER BY created_date DESC LIMIT 1) AND pb_betting_ctl.`userId`=userIds AND pb_betting_ctl.game_type=2 AND pb_betting_ctl.`type`=typess;
      SET count_win = FOUND_ROWS ();
      IF count_win = 0
       THEN SET count_win = 1;
      END IF;
      UPDATE pb_users SET pb_users.exp=pb_users.exp+count_win WHERE pb_users.userId=userIds;
     END IF;
     UPDATE pb_betting SET pb_betting.`is_win`=iswin WHERE pb_betting.`id`=identify;
  END LOOP;
  CLOSE cur;
  
  OPEN cur_betting;
  SET _continue=0;
  credit_loops:LOOP
   FETCH cur_betting INTO result,userIds,rounds,game_types,typess,pick_date;
   IF _continue = 1
   THEN LEAVE credit_loops;
   END IF;
   INSERT pb_betting_ctl(content,userId,ROUND,game_type,TYPE,pick_date) VALUES(result,userIds,rounds,2,typess,pick_date);
   END LOOP;
  CLOSE cur_betting;
  UPDATE pb_betting SET pb_betting.`changed`=1 WHERE pb_betting.`round`=day_round AND pb_betting.`game_type`=2;
END;

