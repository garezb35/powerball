create
    definer = root@localhost procedure PARSING_PULL(IN sizeID text)
BEGIN
  PREPARE stmt FROM sizeID;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
END;

